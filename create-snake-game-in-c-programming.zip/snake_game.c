#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

#define WIDTH 20
#define HEIGHT 20

char board[HEIGHT][WIDTH];
int snakeX[100], snakeY[100];
int snakeLength = 3;
int gameOver = 0;
int dx = 0, dy = -1; // Initial direction: up
int foodX, foodY;

void generateFood() {
    do {
        foodX = rand() % (WIDTH - 2) + 1;  // Ensure food is within the box
        foodY = rand() % (HEIGHT - 2) + 1; // Ensure food is within the box
    } while (board[foodY][foodX] != ' ');
}

void initializeGame() {
    for (int i = 0; i < HEIGHT; i++) {
        for (int j = 0; j < WIDTH; j++) {
            board[i][j] = ' ';
        }
    }

    for (int i = 0; i < snakeLength; i++) {
        snakeX[i] = WIDTH / 2;
        snakeY[i] = HEIGHT / 2 + i;
        board[snakeY[i]][snakeX[i]] = 'S';
    }

    generateFood();
}

void moveSnake() {
    int newX = snakeX[0] + dx;
    int newY = snakeY[0] + dy;

    for (int i = snakeLength - 1; i > 0; i--) {
        snakeX[i] = snakeX[i - 1];
        snakeY[i] = snakeY[i - 1];
    }

    snakeX[0] = newX;
    snakeY[0] = newY;
}

int checkCollision() {
    if (snakeX[0] < 1 || snakeX[0] >= WIDTH - 1 || snakeY[0] < 1 || snakeY[0] >= HEIGHT - 1) {
        return 1; // Collision with wall
    }
    for (int i = 1; i < snakeLength; i++) {
        if (snakeX[0] == snakeX[i] && snakeY[0] == snakeY[i]) {
            return 1; // Collision with self
        }
    }
    return 0;
}

void eatFood() {
    if (snakeX[0] == foodX && snakeY[0] == foodY) {
        snakeLength++;
        generateFood();
    }
}

void updateBoard() {
    for (int i = 0; i < HEIGHT; i++) {
        for (int j = 0; j < WIDTH; j++) {
            board[i][j] = ' ';
        }
    }

    for (int i = 0; i < snakeLength; i++) {
        board[snakeY[i]][snakeX[i]] = 'S';
    }

    board[foodY][foodX] = 'F'; // Place food on the board
}

void drawBoard() {
    system("cls");
    for (int i = 0; i < WIDTH + 2; i++) printf("#");
    printf("\n");

    for (int i = 0; i < HEIGHT; i++) {
        printf("#");
        for (int j = 0; j < WIDTH; j++) {
            printf("%c", board[i][j]);
        }
        printf("#\n");
    }

    for (int i = 0; i < WIDTH + 2; i++) printf("#");
    printf("\n");

    // Display score at the bottom
    printf("Score: %d\n", snakeLength - 3);
}

void changeDirection(char key) {
    switch (key) {
        case 'w': dx = 0; dy = -1; break;
        case 's': dx = 0; dy = 1; break;
        case 'a': dx = -1; dy = 0; break;
        case 'd': dx = 1; dy = 0; break;
    }
}

int main() {
    initializeGame();

    while (!gameOver) {
        if (_kbhit()) {
            char key = _getch();
            changeDirection(key);
        }

        moveSnake();
        gameOver = checkCollision();
        eatFood();
        updateBoard();
        drawBoard();

        _sleep(200); // Control the game speed
    }

    printf("Game Over! Your final score is: %d\n", snakeLength - 3);
    return 0;
}
